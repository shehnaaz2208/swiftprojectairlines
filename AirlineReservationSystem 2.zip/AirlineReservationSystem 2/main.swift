//
//  main.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-28.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, Welcome to Airline Reservation System !")

var raman = Passenger()
raman.addPassenger()
print(raman.display())

//var ASD = Employee()
//ASD.addEmployee()
//print(ASD.displayData())
var  A = Reservation()
var choice = 1
var dataHelper = DataHelper()
var reserv = Reservation()

while choice != 6{
    print("\n----What would you like to do today !----")
    print("\t 1 : Search Flight Information ")
    print("\t 2 :Add Reservation ")
    print("\t 3: Show Reservation ")
    print("\t 4 : Update Reservation ")
    print("\t 5 : Cancel Reservation ")
    print("\t 6 : Exit ")
    print("-----------------------------------------")
    print("Enter you choice please : ")
    choice = (Int)(readLine()!)!
    
    switch choice{
        
    case 1:
      dataHelper.displayFlightInformation()
        
    case 2:
        reserv.addReservation()
       
    case 3:
        print(reserv.display())
        
   // case 4:
     //   Reservation.updateReservation()
        
    case 5:
        exit(0)
    default:
        print("Please enter valid Flight option.")
    }
}
