//
//  Reservation.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-28.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Reservation : Passenger {
    var resID : Int?
    var respassid: String?
    var resflightid : String?
    var resdate: Date?
    var resseatno: String?
    var resstatus : ResStatusList
    var resmealtype: String?
    var dataHelper = DataHelper()
    
    var ResID : Int?{
        get { return self.resID}
        set{ self.resID = newValue}
    }
    var Respassid : String?{
        get { return self.respassid}
        set{ self.respassid = newValue}
    }
    var Resflightid : String?{
        get { return self.resflightid}
        set{ self.resflightid = newValue}
    }
    var Resdate : Date?{
        get { return self.resdate}
        set{ self.resdate = newValue}
    }
    var Resseatno : String?{
        get { return self.resseatno}
        set{ self.resseatno = newValue}
    }
    var Resstatus : ResStatusList{
        get { return self.resstatus}
        set{ self.resstatus = newValue}
    }
    var Resmealtype : String?{
        get { return self.resmealtype}
        set{ self.resmealtype = newValue}
    }
    
    
    //computed property
//    var resFare: String?{
//        get{
//            var amount = 0.0
//            if !(self.resflightid?.isEmpty)!{
//                for (_, flight, seats) in self.resflightid{
//                    amount += flight.UnitPrice! * (Double)(seats)
//                }
//            }
//            return amount
//        }
//    }
//
    
    
    
    
    
    override  init(){
        self.resID = 0
        self.respassid = ""
        self.resflightid = ""
        self.resdate = DateFormatter().date(from: "")
        self.resseatno = ""
        self.resstatus = ResStatusList.None
        self.resmealtype = ""
        super.init()
    }
   
    override func display() -> String {
        var returnData = ""
        
        returnData += "\n Reservation ID : \(String(describing: self.ResID ))"
        returnData += "\n Reservation Date : \(String(describing: self.Resdate ))"
        //        returnData += super.displayData()
        returnData += "\n Flight List : "
//        if !(self.resflightid?.isEmpty)!{
//            for (_, flight, seats) in self.resflightid{
//                returnData += "\n \tFlight : \(flight.displayData())"
//                returnData += "\n \tSeats : \(seats)"
//            }
//        }else{
//            returnData += "\n No flight in the reservation"
//        }
        returnData += "\n Reservation Status : \(self.resstatus )"
        returnData += "\n Reservation Seat : \(self.resseatno  ?? "")"
        
        return returnData
        
    }
    
    
func addReservation(){
    dataHelper.displayFlight()
    print("Please enter flight ID to choose any flight from the list : ")
    let selectedFlightID : Int = (Int)(readLine()!)!
    
    if let selectedFlight = dataHelper.searchFlight(flightID: selectedFlightID){
      self.ResID = selectedFlightID
        self.Resdate = Date()
        
        print("How many seats do you want to reserve ? : ")
        let flight : Int = (Int)(readLine()!) ?? 1
        
//        self.reservationFlight += [(flightID: selectedFlightID, flight: selectedFlight)]
//        self.FlightStatus = FlightStatusList.Reserved
        
    }else{
        print("Sorry...The flight you choose is unavailable")
    }
}

//func cancelReservation(){
//    if !resstatus.isEmpty{
//        print("Review your flightInformation \n \(self.displayData())")
//        
//        print("Please enter flight ID to remove from the reservation : ")
//        let selectedFlightID : Int = (Int)(readLine()!)!
//        var flightIndex = -1
        
//        for (index, item) in self.reservationFlight.enumerated(){
//            if (item.productID == selectedFlightID){
//                flightIndex = index
//            }
//        }
//
//        if flightIndex != -1{
//            self.reservationFlight.remove(at: flightIndex)
//            print("The reservation is cancelled")
//        }
//    }else{
//        print("You have no reserved seat in flight")
//    }
// }
}
